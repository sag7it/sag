const uniqid = require('uniqid');

const ObjectId = require('mongodb').ObjectId; 

const COLLECTION_NAME = 'puzzles';

/**
 * Getting all videos and call callback agter successfull getting data from DB
 * 
 * @param {*} req 
 * @param {*} callback 
 */
function getAllVideo(req, callback) {
  return req.db.collection(COLLECTION_NAME)
    .find().toArray((err, results) => callback(results));
}

/**
 * Get video by id from MongoDB collection, callback treatment
 * @param {*} req 
 * @param {*} id 
 * @param {*} callback 
 */
function getVideoById(req, id, callback) {
  return req.db.collection(COLLECTION_NAME)
    .find({ '_id': ObjectId(id) }).toArray((err, results) => callback(results));
}

/**
 * Get video by puzzle id from MongoDB collection, callback treatment
 * @param {*} req 
 * @param {*} id 
 * @param {*} callback 
 */
function getVideoByPuzzleId(req, id, callback) {
  return req.db.collection(COLLECTION_NAME)
    .find({ '_id': ObjectId(id) }).toArray((err, results) => callback(results));
}

/**
 * Create video to MongoDB collection, creating unique ID for future purpuses, callback treatment
 * @param {*} req 
 * @param {*} videoParam 
 * @param {*} callback 
 */
function createVideo(req, videoParam, callback) {
  const ud = uniqid('vid-');
  const video = {
    uid: ud,
    ...videoParam,
    children:[],
    uidp: ud,
  };
  return req.db.collection(COLLECTION_NAME).save(video, callback());
}

/**
 * Attach puzzle to main video
 * @param {*} req 
 * @param {*} id 
 * @param {*} uid 
 * @param {*} videoParam 
 * @param {*} callback 
 */
function attachVideo(req, id, uid, videoParam, callback) {
  const ud = uniqid();
  const video = {
    uid: ud,
    ...videoParam,
    children:[],
    uidp: ud,
  };

  req.db.collection(COLLECTION_NAME)
    .find({ '_id': ObjectId(id)})
    .toArray(async (err, results) => {
      try {
        const reg = new RegExp(`(\\{){1}(.){0,100}(\\"uid\\":)( ){0,1}(\\")(${uid})(\\")(.*)(\\"uidp\\":)( ){0,1}(\\")(${uid})(\\"\\})`, 'gi');
        const fobj = JSON.parse(JSON.stringify(results).match(reg));
        fobj.children.push(video);
        
        const validVideo = JSON.stringify(results).replace(reg, JSON.stringify(fobj)).replace(/\\/g, '');
        const replacedVideo = JSON.parse(validVideo)[0];
        delete replacedVideo._id;
        
        await req.db.collection(COLLECTION_NAME).save({ '_id': ObjectId(id), ...replacedVideo }, callback());
      } catch (e) {
        console.log(e);
      }
    });
}

/**
 * Delete video or puzzle
 * @param {*} req 
 * @param {*} id 
 * @param {*} uid 
 * @param {*} callback 
 */
function deleteVideoByUID(req, id, uid, callback) {
  console.log(id, uid);
  req.db.collection(COLLECTION_NAME)
    .find({ '_id': ObjectId(id)})
    .toArray(async (err, results) => {
      try {
        const reg = new RegExp(`(,){0,1}(\\{){1}(.){0,100}(\\"uid\\":)( ){0,1}(\\")(${uid})(\\")(.*)(\\"uidp\\":)( ){0,1}(\\")(${uid})(\\"\\})(,){0,1}`, 'gi');
        const t = JSON.stringify(results).replace(reg, '').replace(/\\/g, '');
        let replacedVideo = [];
        
        try {
          replacedVideo = JSON.parse(t)[0];
          delete replacedVideo._id;
        } catch (e) {}

        if (!replacedVideo || replacedVideo.lenght === 0 || Object.keys(replacedVideo).length === 0) {
          await req.db.collection(COLLECTION_NAME).remove({ '_id': ObjectId(id) }, callback()); 
        } else {
          await req.db.collection(COLLECTION_NAME).save({ '_id': ObjectId(id), ...replacedVideo }, callback());
        }

      } catch (e) {
        console.log(e);
      }
    });
}

module.exports = {
  getAllVideo,
  getVideoById,
  createVideo,
  attachVideo,
  deleteVideoByUID,
};
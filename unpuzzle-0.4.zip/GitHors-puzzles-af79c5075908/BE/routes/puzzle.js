const express = require('express');
const router = express.Router();

const { getAllVideo, getVideoById, createVideo, deleteVideoByUID, attachVideo } = require('../actions/puzzle.js')

// route for getting all videos (main video from which we build sunburst)
router.get('/puzzle', async function(req, res, next) {
  await getAllVideo(req, (results) => {
    res.json({ results });
  });
});

// route for creating new videos (main video from which we build sunburst)
router.post('/puzzle', async function(req, res, next) {
  await createVideo(req, req.body, () => {
    res.sendStatus(200);
  });
});

// route for attach puzzle to video or another puzlle
router.post('/puzzle/:id/attach/:uid', async function(req, res, next) {
  await attachVideo(req, req.params.id, req.params.uid, req.body, () => {
    res.sendStatus(200);
  });
});

// route for getting puzzle by id grom MongoDB collection
router.get('/puzzle/:id', async function(req, res, next) {
  await getVideoById(req, req.params.id, (results) => {
    res.json({ results });
  });
});

// route for deleting video by id from MongoDB collection
router.delete('/puzzle/:id', async function(req, res, next) {
  await deleteVideoById(req, req.params.id, () => res.sendStatus(200));
});

// route for deleting puzzle from video or another puzzle
router.delete('/puzzle/:id/puz/:uid', async function(req, res, next) {
  await deleteVideoByUID(req, req.params.id, req.params.uid, () => res.sendStatus(200));
});

module.exports = router;

import React, { Component } from 'react';
import { connect } from 'react-redux';
import { bindActionCreators } from 'redux';
import { RaisedButton } from 'material-ui';
import axios from 'axios';

import { getVideos } from '../actions/video/video';

import Header from '../components/Common/Header'
import VideoList from '../components/VideoList/VideoList';

import './App.css';

const apiUrl = 'http://localhost:3001/puzzle';

class App extends Component {
  
  componentWillMount() {
    this.props.getVideos();
  }

  componentWillUnmount() {
    this.state.player.dispose();
  }

  addVideo(e) {
    e.preventDefault();
    const video = {
      name: this._title.value,
      description: this._description.value,
      videoUrl: this._video.value,
      size: this._size.value,
    };
    axios.post(apiUrl, video)
      .then((res) => {
        setTimeout(() => {window.location.href = '/'}, 1000);
      });
  }

  attachVideo(id, uid, video) {
    axios.post(`${apiUrl}/${id}/attach/${uid}`, video)
      .then((res) => {
        setTimeout(() => {window.location.href = '/'}, 1000);
      });
  }

  removeVideo(id, uid) {
    axios.delete(`${apiUrl}/${id}/puz/${uid}`)
      .then((res) => {
        setTimeout(() => {window.location.href = '/'}, 1000);
      });
  }
  
  render(){
    return (
      <div>
        <Header amount={this.props.videos.length}/>
        <form className="video-form" onSubmit={this.addVideo.bind(this)}>
          <input className="form__field" placeholder="Title" ref={(a) => this._title = a}></input>
          <input className="form__field" placeholder="Description" ref={(b) => this._description = b}></input>
          <input className="form__field" placeholder="Youtube video" ref={(c) => this._video = c}></input>
          <input className="form__field" placeholder="size" ref={(d) => this._size = d}></input>
          <RaisedButton className="btn" type="submit">Add</RaisedButton>
        </form>
        <VideoList
          videos={this.props.videos}
          remove={this.removeVideo.bind(this)}
          attachVideo={this.attachVideo.bind(this)}
          get={this.props.getVideos}
        />
      </div>
    );
  }
}

const mapStateToProps = state => ({
  videos: state.video.videos,
});

const mapDispatchToProps = dispatch => bindActionCreators({
  getVideos
}, dispatch);

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(App);
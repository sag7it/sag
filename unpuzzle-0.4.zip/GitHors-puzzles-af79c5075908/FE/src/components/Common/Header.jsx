import React, { Component } from 'react';
import { AppBar } from 'material-ui';

export default class Header extends Component {
  render() {
    return (
      <AppBar className="title" title={`Puzzles amount: ${this.props.amount}`}>
      </AppBar>
    );
  }
};

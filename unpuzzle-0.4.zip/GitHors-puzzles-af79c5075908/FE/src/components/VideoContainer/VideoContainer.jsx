import React, { Component } from 'react';
import Sunburst from 'react-sunburst-d3-v4';
import { Card, RaisedButton, AutoComplete } from 'material-ui';
import ReactPlayer from 'react-player'

export default class VideoContainer extends Component {
  constructor(p) {
    super(p);
    
    this.state = {
      sunbursMainVideo: this.props.video,
      video: this.props.video
    };
  }

  componentDidMount() {}

  componentWillUnmount() {}

  onSelect(event){
    this.setState({
      video: event.data,
    });
  }

  deleteHandle() {
    this.props.remove(this.state.sunbursMainVideo._id, this.state.video.uid)
  }

  attachVideo(e) {
    e.preventDefault();
    const video = {
      name: this._puzzleTitle.value,
      description: this._puzzleDescription.value,
      videoUrl: this._puzzleVideo.value,
      size: this._puzzleSize.value,
    };
    this.props.attachVideo(this.state.sunbursMainVideo._id, this.state.video.uid, video);
  }

  render() {
    const { id: id, videoUrl: src } = this.state.sunbursMainVideo;
    return (
      <Card className="content"   expanded="false" expandable="true">
      <div className="video-sunburst-left">
        <Sunburst
          data={this.state.sunbursMainVideo}
          onSelect={this.onSelect.bind(this)}
          scale="linear"
          tooltipContent={ <div class="sunburstTooltip sunburst-tooltip" /> }
          tooltip
          keyId={`${this.state.sunbursMainVideo.uid}-sun`}
          tooltipPosition="right"
          width="480"
          height="400"
        />
      </div>
      
      <div className="video-sunburst-right">
      <h1>Title: {this.state.video.name}</h1>
        <p>Description: {this.state.video.description}</p>
        
        <div className="video-player-form">
          <ReactPlayer
            url={this.state.video.videoUrl}
            controls={true}
            width='100%'
            height='100%'
            config={{
              youtube: {
                playerVars: { showinfo: 1 }
              }
            }}
          />
        </div>
        
         <form className="puzzle-form" onSubmit={this.attachVideo.bind(this)}>
          <input className="form__field" placeholder="Title" ref={(a) => this._puzzleTitle = a}></input>
          <input className="form__field" placeholder="Description" ref={(a) => this._puzzleDescription = a}></input>
          <input className="form__field" placeholder="Youtube video" ref={(a) => this._puzzleVideo = a}></input>
          <input className="form__field" placeholder="size" ref={(a) => this._puzzleSize = a}></input>
          <RaisedButton className="btn" title="Remove current puzzle" onClick={this.deleteHandle.bind(this)}>Remove</RaisedButton>
          <RaisedButton className="btn" type="submit">Add</RaisedButton>
        </form>
      </div>
      </Card>
    );
  }
}
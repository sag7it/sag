import React, { Component } from 'react';
import VideoContainer from '../VideoContainer/VideoContainer';

export default class VideoList extends Component {
  buildVideoNodes() {
    const videoNode = this.props.videos.map((video) => {
      return (
        <VideoContainer
          video={video}
          key={video.uid}
          remove={this.props.remove}
          attachVideo={this.props.attachVideo}
          get={this.props.get}
          />
      );
    });
    return videoNode;
  }

  render() {
    return (
      <div className="list-group" style={{marginTop:'30px'}}>{this.buildVideoNodes()}</div>
    );
  };
};
import {
  GET_VIDEO_REQUEST,
  GET_VIDEO_SUCCESS,
  GET_VIDEO_FAILURE,
} from '../constants/video.js';

const initialState = {
  videos: []
};

export default function video(state = initialState, action) {
  switch (action.type) {
    case GET_VIDEO_REQUEST:
      return { 
        ...state,
      }
    case GET_VIDEO_SUCCESS:
      return { 
        ...state,
        videos: action.videos
      }
    case GET_VIDEO_FAILURE:
      return { 
        ...state,
        errors: action.errors
      }
    default:
      return state;
    }
}
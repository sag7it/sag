import React from 'react';
import { render } from 'react-dom';
import { Provider } from 'react-redux';
import { AppContainer } from 'react-hot-loader'
import MuiThemeProvider from 'material-ui/styles/MuiThemeProvider';
import store from './store';
import App from './containers/App.jsx';


const target = document.getElementById('root');

render(
  <Provider store={store}>
    <AppContainer>
      <MuiThemeProvider>
        <App /> 
      </MuiThemeProvider>
    </AppContainer>
  </Provider>,
  target
);

if (module.hot) {
  module.hot.accept('./containers/App', () => {
    render(App)
  })
}

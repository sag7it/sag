import axios from 'axios';

import {
  GET_VIDEO_REQUEST,
  GET_VIDEO_SUCCESS,
  GET_VIDEO_FAILURE,
} from '../../constants/video.js';

const API_URL = 'http://localhost:3001/puzzle';

export const getVideos = () => {
  return dispatch => {
    dispatch({
      type: GET_VIDEO_REQUEST
    });

    axios.get(API_URL)
      .then(function (response) {
        dispatch({
          type: GET_VIDEO_SUCCESS,
          videos: response.data.results
        });
      })
      .catch(function (response) {
        dispatch({
          type: GET_VIDEO_FAILURE,
          errors: response.errors
        });
      });
  }
}

export function getVideosSucces(res) {
  return {
    type: GET_VIDEO_SUCCESS,
    videos: res.videos,
  }
}

export function getVideosFailure(res) {
  return {
    type: GET_VIDEO_FAILURE,
    errors: res.errors,
  }
}

const API_URL = 'http://localhost:3001/puzzle';

export default API_URL;